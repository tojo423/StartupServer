const User = require("./User");
const Startup = require("./Startup");
const Investment = require("./Investment");

module.exports = { User, Startup, Investment };
