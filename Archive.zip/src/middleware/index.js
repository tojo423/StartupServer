const auth = require("./auth");
const errorHandling = require("./error-handling");

module.exports = {
  auth,
  errorHandling,
};
