const errorHandling = require("./error-handling");
const auth = require("./auth");

module.exports = {
  errorHandling,
  auth,
};
